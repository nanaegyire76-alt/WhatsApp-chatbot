require("dotenv").config();

module.exports = {
  // Meta WhatsApp Cloud API
  WHATSAPP_TOKEN: process.env.WHATSAPP_TOKEN,
  WHATSAPP_PHONE_NUMBER_ID: process.env.WHATSAPP_PHONE_NUMBER_ID,
  WHATSAPP_VERIFY_TOKEN: process.env.WHATSAPP_VERIFY_TOKEN,

  // Anthropic
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,

  // Identity
  YOUR_NAME: process.env.YOUR_NAME || "Nana",
  YOUR_WHATSAPP_NUMBER: process.env.YOUR_WHATSAPP_NUMBER,

  // Server
  PORT: process.env.PORT || 3000,

  // Agent behaviour
  MAX_HISTORY_MESSAGES: 30,      // How many past messages to load per contact
  REPLY_DELAY_MS: 1500,          // Small delay before replying (feels more human)
};
