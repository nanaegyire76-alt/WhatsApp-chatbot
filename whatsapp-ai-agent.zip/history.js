/**
 * history.js
 * Manages per-contact conversation history in memory.
 * Keeps the last N messages so Claude has context per person.
 */

const { MAX_HISTORY_MESSAGES } = require("./config");

// In-memory store: { phoneNumber: [ {role, content}, ... ] }
const contactHistories = {};

/**
 * Add a message to a contact's history
 * @param {string} contactPhone - the sender's phone number
 * @param {"user"|"assistant"} role
 * @param {string} content - the message text
 */
function addMessage(contactPhone, role, content) {
  if (!contactHistories[contactPhone]) {
    contactHistories[contactPhone] = [];
  }

  contactHistories[contactPhone].push({ role, content });

  // Keep only the last MAX_HISTORY_MESSAGES messages
  if (contactHistories[contactPhone].length > MAX_HISTORY_MESSAGES) {
    contactHistories[contactPhone] = contactHistories[contactPhone].slice(
      -MAX_HISTORY_MESSAGES
    );
  }
}

/**
 * Get a contact's message history
 * @param {string} contactPhone
 * @returns {Array} array of {role, content} objects
 */
function getHistory(contactPhone) {
  return contactHistories[contactPhone] || [];
}

/**
 * Check if this is a new contact (no history yet)
 * @param {string} contactPhone
 * @returns {boolean}
 */
function isNewContact(contactPhone) {
  return (
    !contactHistories[contactPhone] ||
    contactHistories[contactPhone].length === 0
  );
}

/**
 * Clear history for a contact (optional utility)
 * @param {string} contactPhone
 */
function clearHistory(contactPhone) {
  delete contactHistories[contactPhone];
}

module.exports = { addMessage, getHistory, isNewContact, clearHistory };
