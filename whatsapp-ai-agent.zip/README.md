# 🤖 Nana AI WhatsApp Agent

An AI agent that replies to your WhatsApp messages while you're offline — powered by Meta's official WhatsApp Cloud API and Claude AI. Adapts its tone per contact.

---

## ✅ Prerequisites

- A **Facebook Business account**
- A **Meta Developer account** (free at developers.facebook.com)
- An **Anthropic API key** (console.anthropic.com)
- A **Railway account** (railway.app) for hosting

---

## STEP 1 — Set Up Meta WhatsApp Cloud API

### 1.1 Create a Meta App
1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Click **My Apps → Create App**
3. Choose **Business** as the app type
4. Give it a name (e.g. "Nana AI Agent")
5. Click **Add Product** → find **WhatsApp** → click **Set Up**

### 1.2 Get Your Credentials
In your app dashboard under **WhatsApp → API Setup**:
- Copy your **Temporary Access Token** → this is your `WHATSAPP_TOKEN`
- Copy your **Phone Number ID** → this is your `WHATSAPP_PHONE_NUMBER_ID`

> ⚠️ The temporary token expires in 24 hours. See Step 5 to get a permanent token.

---

## STEP 2 — Deploy to Railway

### 2.1 Push Code to GitHub
1. Create a new GitHub repo (e.g. `whatsapp-ai-agent`)
2. Upload all these files to it

### 2.2 Deploy on Railway
1. Go to [railway.app](https://railway.app) and sign up
2. Click **New Project → Deploy from GitHub repo**
3. Select your repo
4. Railway auto-detects Node.js and deploys

### 2.3 Add Environment Variables on Railway
In your Railway project → **Variables** tab, add:

```
WHATSAPP_TOKEN=your_token_here
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id
WHATSAPP_VERIFY_TOKEN=nana_secret_2024    ← make up any string
ANTHROPIC_API_KEY=your_claude_api_key
YOUR_NAME=Nana
YOUR_WHATSAPP_NUMBER=+233XXXXXXXXX
PORT=3000
```

### 2.4 Get Your Public URL
After deploy, Railway gives you a URL like:
`https://whatsapp-ai-agent-production.up.railway.app`

Save this — you need it for the next step.

---

## STEP 3 — Connect Webhook to Meta

1. In Meta Developer dashboard → **WhatsApp → Configuration**
2. Under **Webhook**, click **Edit**
3. Set:
   - **Callback URL**: `https://YOUR_RAILWAY_URL/webhook`
   - **Verify Token**: same string you set as `WHATSAPP_VERIFY_TOKEN`
4. Click **Verify and Save**
5. Under **Webhook Fields**, subscribe to **messages**

✅ If verification succeeds, your agent is now connected!

---

## STEP 4 — Test It

1. In Meta dashboard → **WhatsApp → API Setup**
2. Send a test message to your WhatsApp number from the dashboard
3. Check Railway logs — you should see the message received and reply sent

Or just **text your WhatsApp Business number** from any phone!

---

## STEP 5 — Get a Permanent Access Token (Important!)

The temporary token expires. To get a permanent one:

1. Go to your Facebook Business Settings
2. Create a **System User** with admin access
3. Generate a **permanent token** for that system user
4. Give it `whatsapp_business_messaging` and `whatsapp_business_management` permissions
5. Replace `WHATSAPP_TOKEN` in Railway with this permanent token

Full guide: [Meta System User Token Docs](https://developers.facebook.com/docs/whatsapp/business-management-api/get-started#system-user-access-tokens)

---

## STEP 6 — Customize Your Personality

Edit `agent.js` → find the `BASE_PERSONALITY` section and update:
- Your bio/description
- How you text
- Topics to avoid
- Any specific phrases you use

---

## 💡 How the AI Adapts

| Contact Type | What Claude Does |
|---|---|
| **Existing contact** | Reads last 30 messages, matches your established tone with them |
| **New contact** | Analyzes their writing style (formal/casual/pidgin) and replies appropriately |
| **Pidgin/Twi speaker** | Responds in kind naturally |
| **Formal message** | Replies professionally |

---

## 📁 File Structure

```
whatsapp-ai-agent/
├── index.js        ← Main server + webhook handler
├── agent.js        ← Claude AI + personality logic
├── history.js      ← Per-contact conversation memory
├── config.js       ← Settings loader
├── package.json    ← Dependencies
├── .env.example    ← Environment variables template
└── README.md       ← This guide
```

---

## 🔧 Local Testing (Optional)

```bash
npm install
cp .env.example .env
# Fill in your .env values
npm run dev
# Use ngrok to expose localhost: ngrok http 3000
```

---

## ⚠️ Notes

- **Memory is in-RAM** — history resets if server restarts. For persistent memory, a database (Supabase) can be added later.
- **Only text messages** are handled for now — images, voice notes are skipped.
- **Rate limits** — Meta has messaging limits depending on your Business verification tier.
