/**
 * agent.js
 * Claude AI agent that replies as Nana.
 * - For existing contacts: uses chat history to match established tone
 * - For new contacts: analyzes their message style and adapts accordingly
 */

const Anthropic = require("@anthropic-ai/sdk");
const { ANTHROPIC_API_KEY, YOUR_NAME } = require("./config");
const { getHistory, isNewContact } = require("./history");

const client = new Anthropic({ apiKey: ANTHROPIC_API_KEY });

// ============================================================
// CORE PERSONALITY PROMPT
// Edit this section to match YOUR real personality, job, topics
// ============================================================
const BASE_PERSONALITY = `
You are acting as ${YOUR_NAME}, a real person. You are replying to WhatsApp messages on their behalf while they are offline.

WHO ${YOUR_NAME} IS:
- A Ghanaian entrepreneur and digital creator based in Ghana
- Founder of "Nana The AI Guru" — helps people use AI tools to make money online
- Builds AI-powered web apps, digital products, and educational content
- Also runs a content channel called MindFold76 covering psychology, history, tech, and civilization
- Very knowledgeable about AI, online income, mobile money (MoMo), and the Ghanaian digital space
- Friendly, smart, and straight to the point
- Speaks naturally — not robotic, not overly formal

HOW ${YOUR_NAME} TEXTS:
- Casual and warm with friends, more professional with business contacts
- Uses occasional Ghanaian expressions naturally (not forced)
- Keeps replies concise — doesn't write essays on WhatsApp
- Sometimes uses emojis but not excessively
- Direct and helpful — always tries to actually answer the question

WHAT ${YOUR_NAME} WON'T DO:
- Share personal financial details or passwords
- Make promises or commitments on business deals
- Discuss deeply personal/private matters — deflects politely
- Pretend to be available when offline — if asked, says "I'm a bit tied up, will get back to you properly soon"

IMPORTANT RULES:
- Never reveal you are an AI unless directly and seriously asked
- If directly asked "are you a bot/AI?", respond naturally: "Haha no, just using an auto-reply while I'm away 😄"
- Keep the conversation going naturally — don't give dead-end replies
- Match the language of the sender if they write in Twi or pidgin, respond appropriately
- Never send more than 3 short paragraphs in one reply — this is WhatsApp, not email
`;

// ============================================================

/**
 * Analyze a new contact's message style
 * @param {string} message
 * @returns {string} style description for the prompt
 */
function analyzeMessageStyle(message) {
  const lower = message.toLowerCase();

  // Detect writing style signals
  const isFormal =
    /\b(dear|hello|good morning|good afternoon|sir|madam|kindly|regards)\b/.test(
      lower
    );
  const isCasual =
    /\b(hey|yo|sup|lol|lmao|omg|bruh|bro|sis|wyd|hbu)\b/.test(lower);
  const isPidgin =
    /\b(abeg|abi|na|wahala|sabi|dey|wey|make|dem|nah|chale|charle|ei|herh)\b/.test(
      lower
    );
  const isShort = message.trim().split(" ").length < 6;
  const hasEmojis = /\p{Emoji}/u.test(message);

  if (isPidgin)
    return "The sender is writing in West African pidgin/Ghanaian slang. Reply naturally in a similar casual Ghanaian style, using appropriate expressions.";
  if (isFormal)
    return "The sender is writing formally and professionally. Reply in a polished but warm professional tone.";
  if (isCasual)
    return "The sender is writing very casually. Match their energy — be relaxed, friendly, and brief.";
  if (isShort && hasEmojis)
    return "The sender uses short messages and emojis. Keep your reply short and use emojis naturally.";
  if (isShort)
    return "The sender keeps messages brief. Mirror that — be concise and direct.";

  return "Reply in your natural warm and friendly tone.";
}

/**
 * Generate a reply using Claude
 * @param {string} contactPhone - sender's phone number
 * @param {string} incomingMessage - the message they sent
 * @param {string} contactName - sender's name if known
 * @returns {Promise<string>} Claude's reply
 */
async function generateReply(contactPhone, incomingMessage, contactName) {
  const history = getHistory(contactPhone);
  const newContact = isNewContact(contactPhone);

  // Build the system prompt
  let systemPrompt = BASE_PERSONALITY;

  if (newContact) {
    // Analyze their style for new contacts
    const styleNote = analyzeMessageStyle(incomingMessage);
    systemPrompt += `\n\nCONTEXT: This is a NEW contact you haven't spoken with before.`;
    if (contactName) {
      systemPrompt += ` Their name is ${contactName}.`;
    }
    systemPrompt += `\nSTYLE GUIDE: ${styleNote}`;
  } else {
    // Use history context for existing contacts
    systemPrompt += `\n\nCONTEXT: You have an existing conversation with this person.`;
    if (contactName) {
      systemPrompt += ` Their name is ${contactName}.`;
    }
    systemPrompt += ` Study the conversation history provided and match the exact tone and style you've been using with them.`;
  }

  // Build messages array from history + new message
  const messages = [
    ...history,
    { role: "user", content: incomingMessage },
  ];

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 300, // Keep replies short — it's WhatsApp
      system: systemPrompt,
      messages: messages,
    });

    return response.content[0].text.trim();
  } catch (error) {
    console.error("Claude API error:", error.message);
    // Fallback reply if Claude fails
    return "Hey! I'm a bit tied up right now, I'll get back to you soon 🙏";
  }
}

module.exports = { generateReply };
